from __future__ import absolute_import
from .rasa_chinese_extend_plugin import *

name = "rasa_chi_plugin"

